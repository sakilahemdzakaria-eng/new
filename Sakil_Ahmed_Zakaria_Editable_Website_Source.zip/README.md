# Sakil Ahmed Zakaria — Editable Portfolio Website

This folder contains the complete editable source for the portfolio website.

## Files
- `index.html` — all website text and page structure
- `css/styles.css` — colours, typography, spacing, layout, mobile styles and animations
- `js/script.js` — interactive process section, ROI estimator and contact buttons
- `images/portrait.jpg` — profile image
- `images/audience-insights.jpg` — campaign audience result screenshot
- `images/top-content.jpg` — campaign performance screenshot

## How to edit
1. Open `index.html` in VS Code or another code editor.
2. Change headings, descriptions, links and contact details directly in the HTML.
3. Edit colours and layout in `css/styles.css`. Main colours are inside the `:root` section near the top.
4. Edit calculator/process behaviour in `js/script.js`.
5. Replace images by keeping the same filenames, or update the image path in `index.html`.

## Preview locally
Double-click `index.html` to open it in a browser, or use the VS Code Live Server extension.

## Important contact details currently used
- WhatsApp: +44 7448 392391
- Email: sakilahemdzakaria@gmail.com

The site uses Google Fonts, so an internet connection is required for the Anton and Plus Jakarta Sans fonts to load.
