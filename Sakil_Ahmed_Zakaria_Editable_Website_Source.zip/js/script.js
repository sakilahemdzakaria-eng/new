// Process steps
var S=[
 ["Define","I learn the restaurant's menu, busy nights and customers, then set one clear goal for the campaign.","#2a64c4"],
 ["Design","I build the offer, the posts and the ad plan around that goal, and share a simple schedule you can approve.","#f2b01e"],
 ["Deliver","I launch, answer messages quickly and report orders and revenue so you can see what worked.","#d9472b"]];
var sp=[].slice.call(document.querySelectorAll('#steps span'));
function step(i){
  sp.forEach(function(s,j){s.classList.toggle('on',i===j)});
  document.getElementById('stepTxt').textContent=S[i][1];
  document.getElementById('shot').style.background=S[i][2];
  document.getElementById('shotTxt').innerHTML=S[i][0].toUpperCase()+'<small>Step '+(i+1)+' of 3</small>';
}
sp.forEach(function(s,i){s.addEventListener('mouseenter',function(){step(i)});s.addEventListener('focus',function(){step(i)});s.addEventListener('click',function(){step(i)})});
step(0);
// ROI estimator
var CITY=[["London",1.25],["Birmingham",1.1],["Manchester",1.1],["Leeds",1.0],["Bradford",.95],["Other UK",.9]];
var GOAL=[["Fill weekend tables",3.2],["Boost takeaway orders",3.8],["Launch a festive offer",4.1],["Win corporate lunches",2.6]];
var ci=1,gi=0;
function mk(id,arr,get,set){
  var box=document.getElementById(id);
  arr.forEach(function(x,i){var b=document.createElement('button');b.type='button';b.textContent=x[0];
    b.onclick=function(){set(i);[].forEach.call(box.children,function(c,j){c.setAttribute('aria-pressed',j===get())});calc()};
    b.setAttribute('aria-pressed',i===get());box.appendChild(b)});
}
mk('city',CITY,function(){return ci},function(i){ci=i});
mk('goal',GOAL,function(){return gi},function(i){gi=i});
var money=function(n){return '£'+Math.round(n).toLocaleString('en-GB')};
function calc(){
  var b=+document.getElementById('bud').value, aov=+document.getElementById('venue').value;
  var rev=b*GOAL[gi][1]*CITY[ci][1], ord=Math.round(rev/aov), tw=Math.max(1,Math.round(ord/4/3));
  document.getElementById('budv').textContent=money(b);
  document.getElementById('o0').textContent=money(b);
  document.getElementById('o1').textContent='+'+tw;
  document.getElementById('o2').textContent='~'+ord.toLocaleString('en-GB');
  document.getElementById('o3').textContent='~'+money(rev);
  document.getElementById('ins').textContent='Goal: '+GOAL[gi][0].toLowerCase()+' in '+CITY[ci][0]+'. Roughly '+(rev/b).toFixed(1)+'x return on your ad spend.';
  var t='Hi Sakil, I ran the planner: '+CITY[ci][0]+', goal "'+GOAL[gi][0]+'", budget '+money(b)+'/month. Estimated revenue '+money(rev)+'. Can we talk?';
  document.getElementById('wa').href='https://wa.me/447448392391?text='+encodeURIComponent(t);
}
['venue','bud'].forEach(function(id){document.getElementById(id).addEventListener('input',calc)});
calc();
// Contact form
function msg(){var g=function(i){return document.getElementById(i).value};
  return 'Hi Sakil, I am '+g('fn')+' from '+g('fr')+'. I need: '+g('fs')+'. '+g('fm')+' (Reply to: '+g('fe')+')'}
document.getElementById('sendwa').onclick=function(){window.open('https://wa.me/447448392391?text='+encodeURIComponent(msg()),'_blank','noopener')};
document.getElementById('sendem').onclick=function(){location.href='mailto:sakilahemdzakaria@gmail.com?subject='+encodeURIComponent('Campaign enquiry')+'&body='+encodeURIComponent(msg())};