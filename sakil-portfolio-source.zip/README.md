# Sakil Ahmed Zakaria: Portfolio Website

Single-page portfolio (HTML + CSS + JavaScript, no build step).

## Run
Open `index.html` in any browser, or serve the folder:
    python3 -m http.server 8000

## Files
- index.html: all markup, styles and scripts
- images/portrait.jpg: hero portrait
- images/audience-insights.jpg, images/top-content.jpg: results screenshots

## Edit
- Contact: search for `sakilahemdzakaria@gmail.com` and `447448392391` in index.html
- Fonts load from Google Fonts (Anton, Plus Jakarta Sans); the site still works offline with fallback fonts
- ROI estimator: see the `CITY` and `GOAL` arrays in the script at the bottom
